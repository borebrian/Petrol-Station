﻿function part() {
    $("#modal1").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modal1').modal("show");
}
function twilio() {
    $("#modal2").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modal2').modal("show");
}
function final() {
    $("#modalfuel").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modalfuel').modal("show");
}
function general() {
    $("#masterd").modal({
        show: false,
        backdrop: 'static'

    });
    $('#masterd').modal("show");
}
function seting() {
    $("#modalfueltest").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modalfueltest').modal("show");
}