﻿function part() {
    $("#modal1").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modal1').modal("show");
}
function twilio() {
    $("#modal2").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modal2').modal("show");
}
function final() {
    $("#modalfuel").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modalfuel').modal("show");
}
function general() {
    $("#masterd").modal({
        show: false,
        backdrop: 'static'

    });
    $('#masterd').modal("show");
}
function seting() {
    $("#modalfueltest").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modalfueltest').modal("show");
}
function sales1() {
    $("#sales").modal({
        show: false,
        backdrop: 'static'

    });
    $('#sales').modal("show");
}
function refill() {
    $("#refill").modal({
        show: false,
        backdrop: 'static'

    });
    $('#refill').modal("show");
}
function showSubmitDialog() {
    $("#modal12").modal({
        show: false,
        backdrop: 'static'

    });
    $('#modal12').modal("show");
}
function nofuel() {
    $("#nofuel").modal({
        show: false,
        backdrop: 'static'

    });
    $('#nofuel').modal("show");
}

function hidModal() {
    $("#modal12").on('hide.bs.modal', function () {
        alert('The modal is about to be hidden.');
    }); 
}
function classic() {
    $("#classic").modal({
        show: false,
        backdrop: 'static'

    });
    $('#classic').modal("show");
}
